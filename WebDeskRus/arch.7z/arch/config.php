<?php
$mysql_user="webdesk";
$mysql_password="qazwsx";
$mysql_db="webdesk";
?>
