<?php
include('config.php');
mysql_connect(null, $mysql_user, $mysql_password);
mysql_select_db($mysql_db) or die(mysql_error());
mysql_query("CREATE TABLE `desks` (`id` BIGINT NOT NULL AUTO_INCREMENT , `key` TEXT NOT NULL , `yyyy` INT NOT NULL , `mm` INT NOT NULL , `dd` INT NOT NULL , `hh` INT NOT NULL , PRIMARY KEY ( `id` ) ) ENGINE = MYISAM ") or die(mysql_error());
mysql_close();
?>
